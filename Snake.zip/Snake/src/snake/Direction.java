
package snake;

public enum Direction {
    RIGHT,
    LEFT,
    UP,
    DOWN,
}
